=== Painterro ===
Contributors: Ivan Borshchov,
Tags: crop, Image editor, paint, image
Requires at least: 3.7
Tested up to: 4.8
Stable tag: 0.2.21
License: MIT
License URI: https://opensource.org/licenses/MIT

Paste screenshots and edit images directly in your wordpress admin.
Adds Painterro button to visual editor for images editing.
Absolutely free and open source.

== Frequently Asked Questions ==

= Where can I report an issue? (Please add 'wordpress' label)

Here: https://github.com/ivictbor/painterro/issues/new

= Where can I suggest a new feature?

Here: https://github.com/ivictbor/painterro/issues/new (Please add 'wordpress' label)

= Where can I found more info about Painterro? =

See readme https://github.com/ivictbor/painterro

== Changelog ==

= 0.2.22 =
* Initial plugin version based on painterro 0.2.22

== Upgrade Notice ==

= 0.2.22 =
Initial plugin version

== Screenshots ==

1. Painterro button
2. Painterro plugin look
3. Rectangle tool
4. Crop tool
5. Color Picker